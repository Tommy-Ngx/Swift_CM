# Color Way

Color Way is a simple 2D game written in Swift.

This game was written as an exercise while learning Swift.


## Preview
https://user-images.githubusercontent.com/17913113/123208447-f57efd80-d473-11eb-8243-c745b69dd6c6.mov



## Installation & Usage
Clone the repo using `$ git clone` or download it and build the project using Xcode.


## Contributing
Contributions are welcomed!


## License
[MIT](LICENSE)
