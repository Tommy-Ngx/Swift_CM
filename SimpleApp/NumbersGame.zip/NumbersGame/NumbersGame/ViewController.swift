//
//  ViewController.swift
//  NumbersGame
//
//  Created by Tihomir RAdeff on 3.07.20.
//  Copyright © 2020 RADEFFFACTORY. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var upButton: UIButton!
    @IBOutlet weak var downButton: UIButton!
    @IBOutlet weak var checkButton: UIButton!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    
    var currentNumber = 25
    var generatedNumber = 0
    
    //score
    var moves = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //button design - rounded corners
        upButton.layer.cornerRadius = 10
        downButton.layer.cornerRadius = 10
        checkButton.layer.cornerRadius = 10
        
        //set label to current number
        numberLabel.text = "\(currentNumber)"
        
        //generate number for guessing between 0 and 50
        generatedNumber = Int.random(in: 0...50)
    }

    @IBAction func upButtonAction(_ sender: Any) {
        //increase the currentNumber + 1
        currentNumber = currentNumber + 1
        
        //if higher than 50 make it 50
        if currentNumber > 50 {
            currentNumber = 50
        }
        
        //set label to current number
        numberLabel.text = "\(currentNumber)"
    }
    
    @IBAction func downButtonAction(_ sender: Any) {
        //decrease the currentNumber - 1
        currentNumber = currentNumber - 1
        
        //if lower than 0 make it 0
        if currentNumber < 0 {
            currentNumber = 0
        }
        
        //set label to current number
        numberLabel.text = "\(currentNumber)"
    }
    
    @IBAction func checkButtonAction(_ sender: Any) {
        //check if higher or lower
        if currentNumber > generatedNumber {
            statusLabel.text = "Lower"
            
            //increase moves
            moves = moves + 1
        } else if currentNumber < generatedNumber {
            statusLabel.text = "Higher"
            
            //increase moves
            moves = moves + 1
        } else {
            statusLabel.text = "You won in \(moves) moves!"
            
            //disable the check button
            checkButton.isUserInteractionEnabled = false
        }
        
        //make animation to the status label
        UIView.transition(with: statusLabel, duration: 0.3, options: .transitionFlipFromBottom, animations: nil, completion: nil)
    }
}

